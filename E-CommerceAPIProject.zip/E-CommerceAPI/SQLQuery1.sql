﻿select * from[dbo].[User_Details]
select * from product detail


